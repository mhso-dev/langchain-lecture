"""Single-process teaching store. Server restart creates a new empty store."""
from threading import RLock
from todo_contract import MAX_ID, TodoError, create_input, id_of, patch_input, query_input, record


class MemoryRepository:
    mode, durable = "server_memory", False

    def __init__(self):
        self._items, self._next, self._lock = {}, 1, RLock()

    def list(self, *, status="all", q=""):
        status, q = query_input(status, q)
        with self._lock:
            return [record(item) for _, item in sorted(self._items.items())
                    if (status == "all" or item["completed"] == (status == "completed")) and q in item["title"]]

    def get(self, todo_id):
        id_of(todo_id)
        with self._lock:
            if todo_id not in self._items:
                raise TodoError("NOT_FOUND", "lookup")
            return record(self._items[todo_id])

    def create(self, body):
        title = create_input(body)
        with self._lock:
            if self._next > MAX_ID:
                raise TodoError("ID_EXHAUSTED", "storage")
            item = {"id": self._next, "title": title, "completed": False}
            self._items[self._next] = item
            self._next += 1
            return record(item)

    def update(self, todo_id, body):
        id_of(todo_id)
        patch = patch_input(body)
        with self._lock:
            current = self.get(todo_id)
            current.update(patch)
            self._items[todo_id] = current
            return record(current)

    def delete(self, todo_id):
        id_of(todo_id)
        with self._lock:
            current = self.get(todo_id)
            del self._items[todo_id]
            return current
