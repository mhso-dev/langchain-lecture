import json
from pathlib import Path
import sys
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def sample(request, server_path=None):
    server_path = server_path or Path(__file__).with_name("mcp_server.py")
    params = StdioServerParameters(command=sys.executable, args=[str(server_path)])
    async with stdio_client(params) as (reader, writer):
        async with ClientSession(reader, writer) as session:
            await session.initialize()
            names = [tool.name for tool in (await session.list_tools()).tools]
            result = await session.call_tool("lookup_policy", request)
            if result.isError:
                raise RuntimeError(result.content[0].text)
            return names, json.loads(result.content[0].text)
