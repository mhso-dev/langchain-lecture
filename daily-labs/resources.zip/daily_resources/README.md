# 하람페이 고객지원 교육 자료
모든 조직·접수·기한은 수업을 위해 직접 만든 가상 자료다. 실제 금융상품 조건이나 고객 데이터는 없다.

documents에는 PDF 5종(각 2쪽), 텍스트 4종(각 2절)이 있다. manifest.csv는 문서 단위, chunks.json은 18개 조항의 예시 인덱스다. PDF 추출 과제에서는 원문을 먼저 읽고 chunks.json으로 대조한다. 날짜 양 끝을 포함한다. valid_to=2099-12-31은 이 실습의 현행판 종료 표기다. 2026년 상반기 부산판과 제주 문서는 제공하지 않는다. 자료가 없는 지역에 다른 지역 정책을 대입하지 않는다.

questions.csv는 자기채점용 12문항이다. 검색기의 입력에는 question, branch, audience, as_of, topic만 준다. gold_chunk와 key는 실행 후 비교할 때만 읽는다. tickets.csv는 중복·지점 누락·0분 완료 기록을 포함한다.

starter에서 자기 구현을 시작하고 reference는 실행 뒤 비교한다. 57–58일에는 skills를 자기 폴더로 복사해 목적·보류 조건을 수정한다. 61일에는 starter/my_server.py를 별도 프로세스로 실행하고, reference/mcp_client.py의 sample(request, server_path=...)로 목록과 실제 결과를 읽는다. 66일 roles.run_roles(request)는 서로 다른 두 create_agent 그래프와 실제 파이썬 도구를 실행한다. 모델 응답을 고정한 대역이며 실제 모델 선택 능력은 별도 관찰한다. reference는 날짜·대상·주제 필터의 기준 구현이며 임베딩 검색과 답변 생성을 대신하지 않는다.

기초 파일 읽기는 Python 표준 라이브러리만 사용한다. PDF 추출은 pypdf, 벡터 실습은 chromadb·faiss-cpu 및 수업 임베딩 모델, MCP·서브에이전트는 mcp·langchain·langgraph가 필요하다. 과목별 기존 노트북에서 사용한 커널을 선택한다. AWS·상용 모델은 수업용 계정이 준비된 환경에서 실행한다. 전체 묶음을 풀면 노트북과 daily_resources가 같은 폴더에 놓인다.

확장 자료 extension/에는 대전 가맹점 업무 매뉴얼 PDF 3쪽과 후속 변경 공지 TXT가 있다. 기본 9개 문서에 추가로 직접 청킹·색인하는 자료다. 시간표만 일부 개정된 상황을 절 단위로 처리한다.
