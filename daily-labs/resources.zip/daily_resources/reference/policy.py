"""지역·대상·판본이 확정된 조항을 읽는 교육용 도구. 날짜 양 끝을 포함한다."""
from datetime import date
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]

def lookup_policy(branch: str, audience: str, as_of: str, topic: str) -> dict:
    if not all([branch.strip(), audience.strip(), as_of.strip(), topic.strip()]):
        return {"status": "clarify", "items": []}
    try:
        day = date.fromisoformat(as_of)
    except ValueError:
        return {"status": "invalid_date", "items": []}
    rows = json.loads((ROOT / "chunks.json").read_text(encoding="utf-8"))
    items = [r for r in rows if (r["branch"], r["audience"], r["topic"]) ==
             (branch, audience, topic) and date.fromisoformat(r["valid_from"]) <= day <= date.fromisoformat(r["valid_to"])]
    return {"status": "ok" if items else "no_evidence", "items": items}

def choose_skill(topic):
    names = {"receipt":"receipt", "export":"export"}
    return names.get(topic)

def load_skill(name):
    if name not in ("receipt", "export"):
        raise ValueError("지원하지 않는 스킬")
    return (ROOT / "skills" / name / "SKILL.md").read_text(encoding="utf-8")

def check_evidence(request, packet):
    allowed = {row["chunk_id"] for row in lookup_policy(**request)["items"]}
    cited = packet.get("citations", [])
    accepted = bool(cited) and all(c in allowed for c in cited)
    return {"status": "accepted" if accepted else "hold", "citations": cited}
