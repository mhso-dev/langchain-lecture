def lookup_policy(branch: str, audience: str, as_of: str, topic: str) -> dict:
    """지점·이용자·기준일·주제에 맞는 정책 조항을 조회합니다."""
    # 1. chunks.json을 읽고 날짜 형식을 검사하세요.
    # 2. 네 조건을 적용한 뒤 clarify / invalid_date / no_evidence / ok 중 하나를 반환하세요.
    raise NotImplementedError("나의 검색 도구를 작성하세요.")
