"""수업용 고정 모델과 실제 create_agent 미들웨어. 실행 시각과 무관하게 같은 제안을 만든다."""
import sqlite3
from langchain.agents import create_agent
from langchain.agents.middleware import HumanInTheLoopMiddleware
from langchain_core.messages import AIMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver
from roles import ClassroomModel

def make_desk(database, request_id, branch):
    @tool
    def register(request_id: str, branch: str) -> str:
        """승인된 가상 자료 재발급 요청을 지점별로 접수합니다."""
        with sqlite3.connect(database) as db:
            db.execute("INSERT INTO desk VALUES (?, ?) ON CONFLICT(id) DO NOTHING", (request_id, branch))
            saved, = db.execute("SELECT branch FROM desk WHERE id=?", (request_id,)).fetchone()
        return "registered" if saved == branch else "conflict"

    with sqlite3.connect(database) as db:
        db.execute("CREATE TABLE IF NOT EXISTS desk(id TEXT PRIMARY KEY, branch TEXT NOT NULL)")
    proposal = AIMessage(content="", tool_calls=[dict(name="register", id="tool-1",
                        args=dict(request_id=request_id, branch=branch))])
    model = ClassroomModel(responses=[proposal, AIMessage(content="처리 종료")])
    review = HumanInTheLoopMiddleware(interrupt_on={"register":{"allowed_decisions":["approve","edit","reject"]}})
    return create_agent(model, tools=[register], middleware=[review], checkpointer=InMemorySaver())
