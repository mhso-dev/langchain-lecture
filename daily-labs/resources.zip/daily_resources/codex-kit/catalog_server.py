"""학습용 읽기 전용 도구. 가상 할 일의 식별자만 조회한다."""
import json
from pathlib import Path
from mcp.server.fastmcp import FastMCP

server = FastMCP("todo_catalog")

@server.tool()
def get_task(item_id: int) -> dict:
    """가상 업무 ID 하나를 조회하고 없으면 missing을 돌려줍니다."""
    rows = json.loads(Path(__file__).with_name("tasks.json").read_text(encoding="utf-8"))
    item = next((row for row in rows if row["id"] == item_id), None)
    return {"status": "found", "item": item} if item else {"status": "missing"}

if __name__ == "__main__":
    server.run(transport="stdio")
