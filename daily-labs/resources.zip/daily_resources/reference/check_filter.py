"""Jupyter에서 check_filter(내_조회함수)를 호출하는 독립 자기점검."""
def check_filter(lookup):
    def result(branch, audience, day, topic="receipt"):
        r=lookup(branch=branch,audience=audience,as_of=day,topic=topic)
        return r["status"], {x["doc_id"] for x in r["items"]}
    cases=[
        (("서울","개인","2026-06-30"),("ok",{"R01"})),
        (("서울","개인","2026-07-01"),("ok",{"R02"})),
        (("부산","개인","2026-09-01"),("ok",{"R03"})),
        (("서울","가맹점","2026-09-01"),("ok",{"R04"})),
        (("제주","개인","2026-09-01"),("no_evidence",set())),
        (("","개인","2026-09-01"),("clarify",set())),
        (("서울","가맹점","2026-09-01","export"),("ok",{"E02"})),
    ]
    for args,expected in cases:
        actual=result(*args)
        assert actual==expected,(args,expected,actual)
    return f"{len(cases)}개 조건 통과"
