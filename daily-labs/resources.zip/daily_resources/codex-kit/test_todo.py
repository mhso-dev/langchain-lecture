import json
from pathlib import Path
import unittest
from todo import complete

class TodoTests(unittest.TestCase):
    def test_second_id_only(self):
        rows = json.loads(Path(__file__).with_name('tasks.json').read_text())
        for row in rows:
            row['done'] = False
        complete(rows, 2)
        self.assertEqual([r['id'] for r in rows if r['done']], [2])
