import asyncio, json, sys
from pathlib import Path
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def probe(server):
    params = StdioServerParameters(command=sys.executable, args=[str(Path(server).resolve())])
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            print([t.name for t in (await session.list_tools()).tools])
            for number in (2, 999):
                result = await session.call_tool("get_task", {"item_id":number})
                print(number, json.loads(result.content[0].text)["status"])
if __name__ == "__main__":
    asyncio.run(probe(Path(__file__).with_name("catalog_server.py")))
