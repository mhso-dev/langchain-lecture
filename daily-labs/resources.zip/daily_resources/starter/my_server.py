from mcp.server.fastmcp import FastMCP
from my_policy import lookup_policy
app = FastMCP("나의 정책 도구")
# 이곳에 lookup_policy를 등록하세요. 등록 전 목록은 비어 있습니다.
if __name__ == "__main__":
    app.run(transport="stdio")
