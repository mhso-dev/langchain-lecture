import {createAPI} from "./client.mjs";
import {createController} from "./controller.mjs";
const controller = createController(createAPI(fetch.bind(window)));
const list = document.querySelector("#list"), form = document.querySelector("#add-form");
const title = document.querySelector("#title"), error = document.querySelector("#error");
function render() {
  const view = controller.view(); list.replaceChildren();
  error.textContent = view.error;
  document.querySelector("#status").textContent = view.busy ? "요청 처리 중" : view.stale ? "재조회 필요 · 이전 확인 목록" : `확인된 할 일 ${view.rows.length}개`;
  for (const item of view.rows) {
    const li = document.createElement("li"), label = document.createElement("label");
    const check = document.createElement("input"); check.type = "checkbox"; check.checked = item.completed;
    check.addEventListener("change", () => act(() => controller.update(item.id, {completed: check.checked})));
    const text = document.createElement("span"); text.textContent = `${item.id}: ${item.title}`;
    label.append(check, text); li.append(label);
    const editor = document.createElement("input"); editor.value = item.title; editor.setAttribute("aria-label", `${item.id}번 제목 수정`);
    const save = document.createElement("button"); save.textContent = "제목 저장";
    save.addEventListener("click", () => act(() => controller.update(item.id, {title: editor.value})));
    const remove = document.createElement("button"); remove.textContent = "삭제";
    remove.addEventListener("click", () => act(() => controller.remove(item.id)));
    li.append(editor, save, remove); list.append(li);
  }
  for (const el of document.querySelectorAll("button,input,select")) el.disabled = view.busy || (view.stale && el.id !== "refresh");
}
async function act(action) {
  const pending = action(); render(); await pending; render();
}
form.addEventListener("submit", event => { event.preventDefault(); act(() => controller.add(title.value)); });
document.querySelector("#refresh").addEventListener("click", () => act(() => controller.refresh()));
act(() => controller.refresh());
