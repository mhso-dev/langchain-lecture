"""의도적으로 잘못 만든 시작 코드. 목록은 호출자가 관리한다."""
def complete(rows, item_id):
    title = next(row['title'] for row in rows if row['id'] == item_id)
    next(row for row in rows if row['title'] == title)['done'] = True
    return rows
