"""Chroma 필터와 재개방 실습. 임베딩 함수는 문서와 질의에 같은 것을 쓴다."""
from pathlib import Path
from datetime import date
import json

def day_number(value):
    return int(date.fromisoformat(value).strftime("%Y%m%d"))

def conditions(branch, audience, topic, as_of):
    day = day_number(as_of)
    return {"$and": [{"branch":{"$eq":branch}}, {"audience":{"$eq":audience}},
                     {"topic":{"$eq":topic}}, {"start":{"$lte":day}}, {"end":{"$gte":day}}]}

def open_index(path, name="practice_policy"):
    import chromadb
    return chromadb.PersistentClient(path=str(path)).get_or_create_collection(name=name)

def ingest(collection, rows, embed):
    texts = [r["title"]+" "+r["text"] for r in rows]
    metadata = [dict(branch=r["branch"],audience=r["audience"],topic=r["topic"],
                     start=day_number(r["valid_from"]),end=day_number(r["valid_to"]),
                     source=r["source"],section=r["section"],doc_id=r["doc_id"]) for r in rows]
    collection.upsert(ids=[r["chunk_id"] for r in rows], documents=texts,
                      embeddings=embed(texts), metadatas=metadata)

def retrieve(collection, case, embed):
    if not case["branch"]:
        return {"status":"clarify","items":[]}
    results = collection.query(query_embeddings=embed([case["question"]]),n_results=2,
                where=conditions(case["branch"],case["audience"],case["topic"],case["as_of"]),
                include=["documents","metadatas","distances"])
    return {"status":"ok" if results["ids"][0] else "no_evidence",
            "items":list(zip(results["ids"][0],results["documents"][0],results["distances"][0]))}

def lexical_vectors(texts):
    """오프라인 비교용 글자 n-gram 벡터. 의미 임베딩 실습에서는 수업 모델의 encode로 교체한다."""
    from sklearn.feature_extraction.text import HashingVectorizer
    return HashingVectorizer(analyzer="char",ngram_range=(2,3),n_features=256,
                             alternate_sign=False).transform(texts).toarray().tolist()
