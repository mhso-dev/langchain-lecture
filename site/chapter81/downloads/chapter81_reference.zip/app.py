"""Prepared FastAPI app. Actual imports/ASGI/HTTP are HOLD while unavailable."""
from pathlib import Path
from api_boundary import dispatch, failure, filters, parse_json, path_id
from memory_store import MemoryRepository
from todo_contract import TodoError


def create_app(*, repository=None, enable_filters=False):
    from fastapi import FastAPI, Request
    from fastapi.responses import JSONResponse, FileResponse
    from fastapi.staticfiles import StaticFiles
    from starlette.exceptions import HTTPException
    repo = MemoryRepository() if repository is None else repository
    app = FastAPI(title="T1 single-user Todo classroom API")
    web = Path(__file__).parent / "web"
    app.mount("/static", StaticFiles(directory=web), name="static")

    def response(value):
        return JSONResponse(status_code=value["status_code"], content=value["body"])

    async def execute(request, operation, raw_id=None):
        try:
            todo_id = path_id(raw_id) if raw_id is not None else None
            query = filters(request.query_params.multi_items(), enabled=enable_filters and operation == "list")
            body = None
            if operation in {"create", "update"}:
                media = request.headers.get("content-type", "").split(";", 1)[0].strip().lower()
                if media != "application/json":
                    raise TodoError("MEDIA_TYPE", "request")
                body = parse_json(await request.body())
            return response(dispatch(repo, operation, body=body, todo_id=todo_id, query=query))
        except TodoError as exc:
            return response(failure(exc.code, exc.stage, mode=repo.mode, durable=repo.durable))

    @app.exception_handler(HTTPException)
    async def http_error(request, exc):
        code = "METHOD_NOT_ALLOWED" if exc.status_code == 405 else "ROUTE_NOT_FOUND"
        value = failure(code, "routing", mode=repo.mode, durable=repo.durable)
        return JSONResponse(status_code=value["status_code"], content=value["body"], headers=exc.headers)

    @app.exception_handler(Exception)
    async def internal_error(request, exc):
        return response(failure("INTERNAL_ERROR", "application", mode=repo.mode, durable=repo.durable, outcome="unknown"))

    @app.get("/")
    def index(): return FileResponse(web / "index.html")

    @app.get("/todos")
    async def list_todos(request: Request): return await execute(request, "list")

    @app.post("/todos")
    async def create_todo(request: Request): return await execute(request, "create")

    @app.get("/todos/{todo_id}")
    async def get_todo(todo_id: str, request: Request): return await execute(request, "get", todo_id)

    @app.patch("/todos/{todo_id}")
    async def update_todo(todo_id: str, request: Request): return await execute(request, "update", todo_id)

    @app.delete("/todos/{todo_id}")
    async def delete_todo(todo_id: str, request: Request): return await execute(request, "delete", todo_id)

    return app
