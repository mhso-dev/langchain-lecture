# 노트북에서 MCP 및 두 역할 실행
전체 묶음을 풀고 Jupyter 커널을 연다. 실제 서버·클라이언트 실행 예시는 다음과 같다.

~~~python
from pathlib import Path
import sys
root = Path("daily_resources").resolve()
sys.path.insert(0, str(root / "reference"))
from mcp_client import sample
from roles import run_roles
request = dict(branch="서울", audience="개인", as_of="2026-07-01", topic="receipt")
names, reply = await sample(request)
print(names, reply["items"][0]["chunk_id"])
print(run_roles(request))
print(run_roles(request, ["R01-1"]))
~~~

정상 근거는 R02-1이다. 두 번째 역할에 전날까지 유효한 R01-1을 넘기면 hold다. 두 에이전트는 별도 메시지 이력을 가진다. 부모는 조회 결과에서 선택한 citations만 검토 역할에 넘긴다. 검토는 출처의 유효 범위를 검사하며 자유문장 전체의 진위를 판정하지 않는다. 스킬은 지침이고 MCP는 도구를 연결하는 인터페이스다.

61일에는 reference 대신 **starter** 아래 파일을 복사해 lookup_policy 구현과 도구 등록을 직접 한다. 위 sample의 두 번째 인자에 완성한 my_server.py 경로를 지정한다. 초기에 도구가 없거나 구현이 예외를 내는 것은 학생이 채울 부분이다.
