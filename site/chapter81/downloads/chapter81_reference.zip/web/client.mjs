// Prepared same-origin transport. No request is sent merely by importing this module.
function row(value) {
  return value && typeof value === "object" && !Array.isArray(value) &&
    Object.keys(value).sort().join(",") === "completed,id,title" &&
    Number.isInteger(value.id) && value.id >= 1 && value.id <= 2147483647 &&
    typeof value.title === "string" && value.title.trim() === value.title && value.title !== "" &&
    typeof value.completed === "boolean";
}
export function createAPI(fetcher) {
  async function request(method, path, body, expectedShape) {
    let response;
    try {
      response = await fetcher(path, {method, ...(body === undefined ? {} : {
        headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)})});
    } catch { throw new Error("NETWORK_UNKNOWN: 자동 재시도하지 마세요"); }
    let value;
    try { value = await response.json(); } catch { throw new Error("RESPONSE_JSON_INVALID"); }
    if (!value || value.contract_version !== "T1-api-v1" || !value.storage ||
        !Object.hasOwn(value, "data") || !Object.hasOwn(value, "error")) throw new Error("RESPONSE_CONTRACT_INVALID");
    if (!response.ok) {
      if (value.data !== null || !value.error || typeof value.error.code !== "string") throw new Error("RESPONSE_CONTRACT_INVALID");
      throw new Error(`${value.error.code}: ${value.storage.outcome}`);
    }
    const data = value.data;
    const validData = expectedShape === "list" ? Array.isArray(data) && data.every(row) : row(data);
    if (value.error !== null || !validData) throw new Error("RESPONSE_CONTRACT_INVALID");
    return value;
  }
  return {
    list: (query = {}) => request("GET", "/todos" + (Object.keys(query).length ? "?" + new URLSearchParams(query) : ""), undefined, "list"),
    create: title => request("POST", "/todos", {title}, "record"),
    update: (id, patch) => request("PATCH", `/todos/${id}`, patch, "record"),
    remove: id => request("DELETE", `/todos/${id}`, undefined, "record")
  };
}
