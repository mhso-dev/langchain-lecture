"""두 create_agent 인스턴스를 부모가 호출하는 재현 예제. 모델 출력 순서만 로컬에서 고정한다."""
import json
from langchain.agents import create_agent
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage
from langchain_core.tools import tool
from langsmith import tracing_context
from policy import lookup_policy, check_evidence, choose_skill, load_skill

class ClassroomModel(FakeMessagesListChatModel):
    def bind_tools(self, tools, **kwargs):
        return self

def run_roles(request, override_citations=None):
    name = choose_skill(request["topic"])
    if not name:
        return {"status":"unsupported","trace":[]}
    instructions = load_skill(name)
    def execute(role, func, args):
        action = tool(func)
        message = AIMessage(content="", tool_calls=[{"name":action.name,
            "args":args, "id":role+"-1"}])
        agent = create_agent(ClassroomModel(responses=[message, AIMessage(content="완료")]),
                             tools=[action], system_prompt=instructions)
        with tracing_context(enabled=False):
            log = agent.invoke({"messages":[("user",json.dumps(args,ensure_ascii=False))]})["messages"]
        output = next(m for m in log if m.type=="tool")
        return json.loads(output.content), [role+":"+m.type for m in log]

    def research(branch: str, audience: str, as_of: str, topic: str) -> dict:
        """기준일에 유효한 문서 후보를 조회합니다."""
        return lookup_policy(branch,audience,as_of,topic)
    def review(citations: list[str]) -> dict:
        """인계받은 근거가 원 요청의 범위에 속하는지 검사합니다."""
        return check_evidence(request,{"citations":citations})

    found, trace = execute("research",research,request)
    if found["status"]!="ok":
        return {"status":found["status"],"trace":trace}
    citations = [found["items"][0]["chunk_id"]] if override_citations is None else override_citations
    result, checks = execute("review",review,{"citations":citations})
    return {**result,"skill":name,"trace":trace+checks}
