// Pure request controller: confirmed rows change only after a successful list response.
export function createController(api) {
  let state = {rows: [], busy: false, stale: true, error: "", query: {}};
  const copy = () => JSON.parse(JSON.stringify(state));
  async function perform(operation, nextQuery = state.query) {
    if (state.busy) return {ignored: true};
    if (operation && state.stale) { state.error = "REFRESH_REQUIRED"; return copy(); }
    state.busy = true; state.error = "";
    try {
      if (operation) await operation();
      const result = await api.list(nextQuery);
      state.rows = JSON.parse(JSON.stringify(result.data));
      state.query = {...nextQuery}; state.stale = false;
    } catch (error) {
      state.error = error instanceof Error ? error.message : "REQUEST_FAILED";
      state.stale = true;
    } finally { state.busy = false; }
    return copy();
  }
  return {
    view: copy,
    refresh: query => perform(null, query === undefined ? state.query : query),
    add: title => perform(() => api.create(title)),
    update: (id, patch) => perform(() => api.update(id, patch)),
    remove: id => perform(() => api.remove(id))
  };
}
