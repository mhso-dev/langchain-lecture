"""SessionStart 이벤트를 받은 횟수를 확인하기 위한 수업용 훅."""
import json
from pathlib import Path
import sys
payload = json.load(sys.stdin)
if payload.get("hook_event_name") == "SessionStart":
    log = Path(__file__).resolve().parent / "hook-events.jsonl"
    with log.open("a", encoding="utf-8") as output:
        output.write(json.dumps({"event":"SessionStart", "source":payload.get("source")}) + "\n")
