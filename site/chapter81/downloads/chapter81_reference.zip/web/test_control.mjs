import test from "node:test";
import assert from "node:assert/strict";
import {createController} from "./controller.mjs";
import {createAPI} from "./client.mjs";
const envelope = data => ({contract_version:"T1-api-v1",data,error:null,storage:{mode:"server_memory",durable:false,outcome:"read_or_memory"}});
const item = {id:1,title:"x",completed:false};

test("initial stale state needs confirmed refresh", async () => {
  let writes=0;const c=createController({create:async()=>writes++,list:async()=>envelope([])});
  await c.add("x");assert.equal(writes,0);assert.equal(c.view().error,"REFRESH_REQUIRED");
  await c.refresh();assert.equal(c.view().stale,false);
});
test("write confirmed by later list, not optimistic append", async()=>{
  let rows=[],release;const c=createController({list:async()=>envelope(rows),create:()=>new Promise(resolve=>{release=()=>{rows=[item];resolve(envelope(item));};})});
  await c.refresh();const p=c.add("x");assert.deepEqual(c.view().rows,[]);assert.equal(c.view().busy,true);
  assert.deepEqual(await c.add("again"),{ignored:true});release();await p;
  assert.deepEqual(c.view().rows,[item]);rows[0]={...item,title:"external"};assert.equal(c.view().rows[0].title,"x");
});
test("failed mutation preserves confirmed rows and requires refresh",async()=>{
  let writes=0;const c=createController({list:async()=>envelope([item]),remove:async()=>{writes++;throw new Error("STORAGE_FAILURE: failed_or_unknown");}});
  await c.refresh();await c.remove(1);assert.deepEqual(c.view().rows,[item]);assert.equal(c.view().stale,true);
  await c.remove(1);assert.equal(writes,1);await c.refresh();assert.equal(c.view().stale,false);
});
test("write success then list failure is stale, no automatic rewrite",async()=>{
  let fail=false,writes=0;const c=createController({list:async()=>{if(fail)throw new Error("NETWORK_UNKNOWN");return envelope([]);},create:async()=>{writes++;fail=true;return envelope(item);}});
  await c.refresh();await c.add("x");assert.equal(writes,1);assert.deepEqual(c.view().rows,[]);assert.equal(c.view().stale,true);
});
test("transport sends explicit title/completed JSON",async()=>{
  const calls=[];const api=createAPI(async(path,options)=>{calls.push([path,options]);return {ok:true,json:async()=>envelope({...item,title:"new",completed:true})};});
  await api.update(1,{title:"new",completed:true});assert.equal(calls[0][0],"/todos/1");assert.equal(calls[0][1].method,"PATCH");
  assert.deepEqual(JSON.parse(calls[0][1].body),{title:"new",completed:true});
});
test("HTTP design error is retained, no successful empty list",async()=>{
  const api=createAPI(async()=>({ok:false,json:async()=>({contract_version:"T1-api-v1",data:null,error:{code:"NOT_FOUND",stage:"lookup"},storage:{outcome:"not_applied"}})}));
  await assert.rejects(api.remove(9),/NOT_FOUND/);
});
test("malformed JSON and wrong boolean are contract failures",async()=>{
  let api=createAPI(async()=>({ok:true,json:async()=>{throw new Error("bad");}}));await assert.rejects(api.list(),/RESPONSE_JSON_INVALID/);
  api=createAPI(async()=>({ok:true,json:async()=>envelope([{...item,completed:"false"}])}));await assert.rejects(api.list(),/RESPONSE_CONTRACT_INVALID/);
});
test("network failure sends only one request",async()=>{
  let calls=0;const api=createAPI(async()=>{calls++;throw new Error("socket");});await assert.rejects(api.create("x"),/NETWORK_UNKNOWN/);assert.equal(calls,1);
});
test("object list response stays stale and preserves last confirmed rows and query",async()=>{
  let data=item;
  const api=createAPI(async()=>({ok:true,json:async()=>envelope(data)}));
  const c=createController(api);
  await c.refresh();
  assert.deepEqual(c.view().rows,[]);assert.equal(c.view().stale,true);
  assert.equal(c.view().error,"RESPONSE_CONTRACT_INVALID");
  data=[item];await c.refresh({status:"active"});
  assert.equal(c.view().stale,false);
  data={...item,title:"wrong response shape"};await c.refresh({status:"completed"});
  assert.deepEqual(c.view().rows,[item]);assert.deepEqual(c.view().query,{status:"active"});
  assert.equal(c.view().stale,true);assert.equal(c.view().error,"RESPONSE_CONTRACT_INVALID");
  assert.equal(c.view().busy,false);
});
test("create update and remove reject even valid record arrays",async()=>{
  for (const data of [[],[item]]) {
    const api=createAPI(async()=>({ok:true,json:async()=>envelope(data)}));
    await assert.rejects(api.create("x"),/RESPONSE_CONTRACT_INVALID/);
    await assert.rejects(api.update(1,{completed:true}),/RESPONSE_CONTRACT_INVALID/);
    await assert.rejects(api.remove(1),/RESPONSE_CONTRACT_INVALID/);
  }
});
test("list accepts empty or populated arrays and writes accept single records",async()=>{
  let data=[];const api=createAPI(async()=>({ok:true,json:async()=>envelope(data)}));
  assert.deepEqual((await api.list()).data,[]);
  data=[item];assert.deepEqual((await api.list()).data,[item]);
  data=item;
  assert.deepEqual((await api.create("x")).data,item);
  assert.deepEqual((await api.update(1,{title:"x"})).data,item);
  assert.deepEqual((await api.remove(1)).data,item);
});
