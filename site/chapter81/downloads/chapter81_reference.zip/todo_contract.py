"""T1 pure validation. Python strip() is intentionally not the JS trim contract."""
import json
from pathlib import Path

T1 = json.loads((Path(__file__).parent / "input80/todo-contract.json").read_text())
TRIM = "".join(chr(int(value, 16)) for value in T1["title"]["trim_codepoints"])
MAX_ID = 2147483647


class TodoError(Exception):
    def __init__(self, code, stage="validation"):
        self.code, self.stage = code, stage
        super().__init__(code)


class StorageFailure(TodoError):
    def __init__(self, outcome):
        self.outcome = outcome
        super().__init__("STORAGE_FAILURE", "storage")


def valid_text(value, code):
    if type(value) is not str:
        raise TodoError(code)
    try:
        value.encode("utf-8")
    except UnicodeEncodeError:
        raise TodoError("INVALID_ENCODING") from None
    return value


def title_of(value):
    value = valid_text(value, "INVALID_TITLE").strip(TRIM)
    if not value:
        raise TodoError("INVALID_TITLE")
    return value


def id_of(value):
    if type(value) is not int or not 1 <= value <= MAX_ID:
        raise TodoError("INVALID_ID")
    return value


def completed_of(value):
    if type(value) is not bool:
        raise TodoError("INVALID_COMPLETED")
    return value


def fields(value, allowed, required=()):
    if type(value) is not dict or any(type(k) is not str for k in value):
        raise TodoError("REQUEST_SHAPE")
    if set(value) - set(allowed) or not set(required) <= set(value):
        raise TodoError("REQUEST_SHAPE")
    return value


def create_input(value):
    fields(value, {"title"}, {"title"})
    return title_of(value["title"])


def patch_input(value):
    fields(value, {"title", "completed"})
    if not value:
        raise TodoError("EMPTY_PATCH")
    # Validate every field before any repository mutation.
    return {k: title_of(v) if k == "title" else completed_of(v) for k, v in value.items()}


def query_input(status="all", q=""):
    if type(status) is not str or status not in {"all", "active", "completed"}:
        raise TodoError("INVALID_FILTER")
    return status, valid_text(q, "INVALID_QUERY").strip(TRIM)


def record(value):
    try:
        fields(value, {"id", "title", "completed"}, {"id", "title", "completed"})
        if title_of(value["title"]) != value["title"]:
            raise ValueError("stored_title_not_normalized")
        return {"id": id_of(value["id"]), "title": value["title"], "completed": completed_of(value["completed"])}
    except (TodoError, ValueError):
        raise TodoError("INVALID_STORED_RECORD", "output") from None
