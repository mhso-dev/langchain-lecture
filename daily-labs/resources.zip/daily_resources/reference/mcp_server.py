"""실제 stdio 서버. 노트북에서 mcp_client.sample을 실행하면 별도 프로세스로 시작된다."""
from mcp.server.fastmcp import FastMCP
from policy import lookup_policy
server = FastMCP("가상 결제 정책")
server.tool()(lookup_policy)
if __name__ == "__main__":
    server.run(transport="stdio")
