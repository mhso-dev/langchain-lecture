"""Todo-only HTTP design values; calling this function is not an HTTP observation."""
import json
import re
from todo_contract import TodoError, StorageFailure, id_of, query_input, record

HTTP = {"NOT_FOUND": 404, "ID_EXHAUSTED": 409, "STORAGE_FAILURE": 503,
        "INVALID_STORED_RECORD": 500, "INTERNAL_ERROR": 500, "MALFORMED_JSON": 400,
        "MEDIA_TYPE": 415, "ROUTE_NOT_FOUND": 404, "METHOD_NOT_ALLOWED": 405}


def failure(code, stage="validation", *, mode="server_memory", durable=False, outcome="not_applied"):
    return {"status_code": HTTP.get(code, 422), "body": {"contract_version": "T1-api-v1", "data": None,
            "error": {"code": code, "stage": stage},
            "storage": {"mode": mode, "durable": durable, "outcome": outcome}}}


def path_id(raw):
    if type(raw) is not str or re.fullmatch(r"[1-9][0-9]{0,9}", raw) is None:
        raise TodoError("INVALID_ID")
    return id_of(int(raw))


def parse_json(raw):
    def invalid_constant(_):
        raise ValueError("non_json_number")
    def unique(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                raise ValueError("duplicate_key")
            value[key] = item
        return value
    try:
        return json.loads(raw.decode("utf-8"), parse_constant=invalid_constant, object_pairs_hook=unique)
    except (ValueError, UnicodeDecodeError, AttributeError):
        raise TodoError("MALFORMED_JSON", "request") from None


def filters(pairs, *, enabled):
    result = {}
    for key, value in pairs:
        if not enabled or key not in {"status", "q"} or key in result:
            raise TodoError("INVALID_QUERY")
        result[key] = value
    return dict(zip(("status", "q"), query_input(**result)))


def dispatch(repo, operation, *, body=None, todo_id=None, query=None):
    mode, durable = repo.mode, repo.durable
    try:
        if operation == "list":
            value = repo.list(**(query or {}))
            if type(value) is not list:
                raise TodoError("INVALID_STORED_RECORD", "output")
            data = [record(row) for row in value]
        elif operation == "get":
            data = record(repo.get(todo_id))
        elif operation == "create":
            data = record(repo.create(body))
        elif operation == "update":
            data = record(repo.update(todo_id, body))
        elif operation == "delete":
            data = record(repo.delete(todo_id))
        else:
            raise TodoError("ROUTE_NOT_FOUND", "routing")
        # No mutation result is declared committed until the repository returns.
        outcome = "committed" if durable and operation in {"create", "update", "delete"} else "read_or_memory"
        return {"status_code": 201 if operation == "create" else 200,
                "body": {"contract_version": "T1-api-v1", "data": data, "error": None,
                         "storage": {"mode": mode, "durable": durable, "outcome": outcome}}}
    except StorageFailure as exc:
        return failure(exc.code, exc.stage, mode=mode, durable=durable, outcome=exc.outcome)
    except TodoError as exc:
        return failure(exc.code, exc.stage, mode=mode, durable=durable)
    except Exception:
        return failure("INTERNAL_ERROR", "application", mode=mode, durable=durable, outcome="unknown")
